// next.config.js
module.exports = {
  images: {
    domains: ['wvstaging.ivistasolutions.biz'],
  },
}